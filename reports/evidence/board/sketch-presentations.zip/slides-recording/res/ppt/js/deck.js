let page=1,step=0;const trace=[];
function show(method) {
 trace.push(method); document.getElementById("title").textContent="Slide "+page+" / 3 · "+step;
 document.querySelector("main").style.backgroundColor=["#b3dace","#ebba74","#8cb1de"][page-1];
 document.getElementById("step").hidden=!step;
 SlideNative.setTotalCount(3); SlideNative.setCurrentSlide(page);
}
window.Presentation={
 Next(){if(step===0)step=1;else{page=Math.min(3,page+1);step=0}show("Next")},
 Prev(){if(step===1)step=0;else{page=Math.max(1,page-1);step=1}show("Prev")},
 NxtSlide(){page=Math.min(3,page+1);step=0;show("NxtSlide")},
 PrvSlide(){page=Math.max(1,page-1);step=0;show("PrvSlide")},
 GotoSlide(n){page=Math.max(1,Math.min(3,Number(n)));step=0;show("GotoSlide:"+typeof n)}
};show("load");